# map-scraper

Background Google Maps scraper (web + worker) for Coolify.
